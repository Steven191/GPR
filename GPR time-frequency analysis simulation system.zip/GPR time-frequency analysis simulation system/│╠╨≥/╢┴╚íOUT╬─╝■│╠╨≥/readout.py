import h5py
import numpy as np
import matplotlib.pyplot as plt
import os

# 导入数据，提取out文件中Ez分量，保存在矩阵b中
path = 'C:/Users/zqw/Documents/WeChat Files/wxid_ykg40lb7tlgp22/FileStorage/File/2023-01/程序/data'
files = os.listdir(path)
# files = ['Bscan_2D.out']
# files = ['cylinder_Bscan_2D.out']

a = []
for file in files:
    f = h5py.File(path+'/'+file, 'r')
    a1 = f['/rxs/rx1/Ez'][:]
    a.append(a1)

b = np.array(a)

def get_max_value(martix):
    '''
    提取振幅最大值
    '''
    res_list = []
    for i in range(len(martix)):
        one_list = []
        for j in range(len(martix[i])):
            one_list.append(float(martix[i][j]))
        res_list.append(str(max(one_list)))
    return res_list

c = np.array(get_max_value(b), dtype=np.float64)
print(type(c))
# 绘制提取出的振幅图
fig,ax = plt.subplots()
t = np.arange(1, 61)
ax.plot(t, c, marker='*')
ax.set_xlabel("Channel Number")
ax.set_ylabel("Ez")
plt.show()
print(c)

# 绘制灰度图
plt.imshow(b, cmap = 'hsv', aspect='auto')
plt.colorbar()
plt.ylabel('Channel Number')
plt.xlabel("Samples")

# 提取单道，绘制单道Ez对比图
x = np.arange(1, b.shape[1]+1)
fig, ax = plt.subplots()
ax.plot(x, 1.17933e-10*b[2], color='red', label="b[2]")
ax.plot(x, 1.17933e-10*b[20], color='blue', label="b[20]")
ax.plot(x, 1.17933e-10*b[38], color='yellow', label="b[38]")
ax.plot(x, 1.17933e-10*b[57], color='green', label="b[57]")
ax.legend()
ax.set_xlabel("Samples")
ax.set_ylabel("Ez")
plt.show()